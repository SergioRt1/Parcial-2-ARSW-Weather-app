package com.example.Weathers.services;

public class WeathersServicesException extends Exception {

	public WeathersServicesException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public WeathersServicesException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
